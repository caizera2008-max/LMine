package com.example.mclist

data class Block(val id: String, val name: String, val color: Int, val stack: Int = 64)

private fun stackOf(id: String) = when {
    id.endsWith("_bed") || id.endsWith("shulker_box") -> 1
    id.endsWith("_banner") || id.endsWith("_sign") || id == "straw_bed" -> 16
    else -> 64
}

private fun b(id: String, name: String, c: Int) = Block(id, name, 0xFF000000.toInt() or c, stackOf(id))
private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }
private fun mix(x: Int, y: Int, t: Float): Int {
    fun ch(s: Int) = (((x shr s) and 255) * (1 - t) + ((y shr s) and 255) * t).toInt()
    return (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
}

// ---------------- Madeiras ----------------
// kind: 0 = árvore, 1 = fungo do Nether, 2 = bambu
private class Wood(val id: String, val de: String, val c: Int, val leaf: Int, val deF: String = de, val kind: Int = 0)

private val WOODS = listOf(
    Wood("oak", " de carvalho", 0xB8945F, 0x3E7A2A),
    Wood("spruce", " de pinheiro", 0x7A5A34, 0x2F5A32),
    Wood("birch", " de bétula", 0xC8B77A, 0x5F8F3A),
    Wood("jungle", " da selva", 0xB88764, 0x2E7D1F),
    Wood("acacia", " de acácia", 0xA95A32, 0x5A8A2A),
    Wood("dark_oak", " de carvalho escuro", 0x4B3219, 0x2F5F1F),
    Wood("mangrove", " de mangue", 0x7B3A3A, 0x4A7A2A),
    Wood("cherry", " de cerejeira", 0xE2B3A9, 0xF0A8C8),
    Wood("pale_oak", " de carvalho pálido", 0xE3D9D0, 0xA8B0A0),
    Wood("poplar", " de choupo", 0x8E8E8A, 0xB5472A),
    Wood("bamboo", " de bambu", 0xC9B04D, 0, kind = 2),
    Wood("crimson", " carmesim", 0x6A2B44, 0, kind = 1),
    Wood("warped", " distorcido", 0x2B6C62, 0, deF = " distorcida", kind = 1),
)

private fun woods(): List<Block> = buildList {
    for (w in WOODS) {
        val i = w.id; val m = w.de; val f = w.deF; val c = w.c
        add(b("${i}_planks", "Tábuas$f", c))
        add(b("${i}_stairs", "Escada$f", c))
        add(b("${i}_slab", "Laje$f", c))
        add(b("${i}_fence", "Cerca$f", c))
        add(b("${i}_fence_gate", "Portão de cerca$m", c))
        add(b("${i}_door", "Porta$f", c))
        add(b("${i}_trapdoor", "Alçapão$m", c))
        add(b("${i}_button", "Botão$m", c))
        add(b("${i}_pressure_plate", "Placa de pressão$f", c))
        add(b("${i}_sign", "Placa$f", c))
        add(b("${i}_hanging_sign", "Placa suspensa$f", c))
        when (w.kind) {
            0 -> {
                add(b("${i}_log", "Tronco$m", mix(c, 0x3A2A18, .4f)))
                add(b("stripped_${i}_log", "Tronco$m sem casca", c))
                add(b("${i}_wood", "Madeira$f", mix(c, 0x3A2A18, .4f)))
                add(b("stripped_${i}_wood", "Madeira$f sem casca", c))
                add(b("${i}_leaves", "Folhas$f", w.leaf))
                if (i == "mangrove") add(b("mangrove_propagule", "Propágulo de mangue", w.leaf))
                else add(b("${i}_sapling", "Muda$f", w.leaf))
            }
            1 -> {
                add(b("${i}_stem", "Caule$m", mix(c, 0x201010, .3f)))
                add(b("stripped_${i}_stem", "Caule$m sem casca", c))
                add(b("${i}_hyphae", "Hifas$f", mix(c, 0x201010, .3f)))
                add(b("stripped_${i}_hyphae", "Hifas$f sem casca", c))
            }
            2 -> {
                add(b("bamboo_block", "Bloco de bambu", c))
                add(b("stripped_bamboo_block", "Bloco de bambu sem casca", c))
            }
        }
    }
}

// ---------------- Cores ----------------
private val DYES = listOf(
    Triple("white", "branco" to "branca", 0xE9ECEC),
    Triple("orange", "laranja" to "laranja", 0xF07613),
    Triple("magenta", "magenta" to "magenta", 0xBD44B3),
    Triple("light_blue", "azul-claro" to "azul-clara", 0x3AAFD9),
    Triple("yellow", "amarelo" to "amarela", 0xF8C527),
    Triple("lime", "verde-limão" to "verde-limão", 0x70B919),
    Triple("pink", "rosa" to "rosa", 0xED8DAC),
    Triple("gray", "cinza" to "cinza", 0x3E4447),
    Triple("light_gray", "cinza-claro" to "cinza-clara", 0x8E8E86),
    Triple("cyan", "ciano" to "ciano", 0x158991),
    Triple("purple", "roxo" to "roxa", 0x792AAC),
    Triple("blue", "azul" to "azul", 0x35399D),
    Triple("brown", "marrom" to "marrom", 0x724728),
    Triple("green", "verde" to "verde", 0x546D1B),
    Triple("red", "vermelho" to "vermelha", 0xA12722),
    Triple("black", "preto" to "preta", 0x141519),
)

private fun dyed(): List<Block> = buildList {
    for ((id, n, c) in DYES) {
        val m = n.first; val f = n.second
        add(b("${id}_wool", "Lã $f", c))
        add(b("${id}_wool_stairs", "Escada de lã $f", c))
        add(b("${id}_wool_slab", "Laje de lã $f", c))
        add(b("${id}_carpet", "Tapete $m", c))
        add(b("${id}_terracotta", "Terracota $f", mix(c, 0x8A5A44, .55f)))
        add(b("${id}_glazed_terracotta", "Terracota esmaltada $f", c))
        add(b("${id}_concrete", "Concreto $m", c))
        add(b("${id}_concrete_stairs", "Escada de concreto $m", c))
        add(b("${id}_concrete_slab", "Laje de concreto $m", c))
        add(b("${id}_concrete_powder", "Pó de concreto $m", mix(c, 0xDDDDDD, .2f)))
        add(b("${id}_stained_glass", "Vidro $m", mix(c, 0xFFFFFF, .55f)))
        add(b("${id}_stained_glass_pane", "Painel de vidro $m", mix(c, 0xFFFFFF, .55f)))
        add(b("${id}_bed", "Cama $f", c))
        add(b("${id}_banner", "Estandarte $m", c))
        add(b("${id}_shulker_box", "Caixa shulker $f", c))
        add(b("${id}_candle", "Vela $f", c))
        add(b("${id}_cushion", "Almofada $f", c))
    }
}

// ---------------- Cobre ----------------
private val STAGES = listOf(
    Triple("", "", 0xC06C4F), Triple("exposed_", " exposto", 0xA07A60),
    Triple("weathered_", " desgastado", 0x6E9D7A), Triple("oxidized_", " oxidado", 0x4FA58A),
)

private fun copper(): List<Block> = buildList {
    for (wax in listOf(false, true)) for ((p, s, c) in STAGES) {
        val w = if (wax) "waxed_" else ""
        val e = if (wax) " encerado" else ""
        fun a(id: String, name: String) = add(b("$w$p$id", "$name$s$e", c))
        add(b("$w${if (p.isEmpty()) "copper_block" else p + "copper"}", "Bloco de cobre$s$e", c))
        a("cut_copper", "Cobre cortado"); a("cut_copper_stairs", "Escada de cobre cortado")
        a("cut_copper_slab", "Laje de cobre cortado"); a("chiseled_copper", "Cobre cinzelado")
        a("copper_grate", "Grade de cobre"); a("copper_door", "Porta de cobre")
        a("copper_trapdoor", "Alçapão de cobre"); a("copper_bulb", "Lâmpada de cobre")
    }
}

// ---------------- Minérios e corais ----------------
private fun ores(): List<Block> = buildList {
    val l = listOf(
        Triple("coal", "carvão", 0x6E6E6E), Triple("iron", "ferro", 0xA08C7C),
        Triple("copper", "cobre", 0x8C7A6B), Triple("gold", "ouro", 0xB6A06A),
        Triple("redstone", "redstone", 0x8E5050), Triple("emerald", "esmeralda", 0x6E8C78),
        Triple("lapis", "lápis-lazúli", 0x6A7490), Triple("diamond", "diamante", 0x7DA8A5),
    )
    for ((i, n, c) in l) {
        add(b("${i}_ore", "Minério de $n", c))
        add(b("deepslate_${i}_ore", "Minério de $n da ardósia", mix(c, 0x4D4D52, .5f)))
    }
}

private fun corals(): List<Block> = buildList {
    val l = listOf(
        Triple("tube", "tubular", 0x3157CC), Triple("brain", "cerebral", 0xC75393),
        Triple("bubble", "de bolhas", 0xA21FA2), Triple("fire", "de fogo", 0xD12F36),
        Triple("horn", "de chifre", 0xD9CD2C),
    )
    for ((i, n, c) in l) {
        add(b("${i}_coral_block", "Bloco de coral $n", c))
        add(b("dead_${i}_coral_block", "Bloco de coral $n morto", 0x7F7C73))
        add(b("${i}_coral", "Coral $n", c))
        add(b("${i}_coral_fan", "Leque de coral $n", c))
    }
}

// ---------------- Famílias de pedra (escada / laje / muro) ----------------
// id;nome;cor;flags(s=escada l=laje w=muro n=sem bloco base);prefixo opcional dos ids derivados
private const val FAMILIES = """
stone;pedra;7D7D7D;sl
cobblestone;pedregulho;6E6E6E;slw
mossy_cobblestone;pedregulho musgoso;6B7A5A;slw
smooth_stone;pedra lisa;9A9A9A;l
stone_bricks;tijolos de pedra;777777;slw;stone_brick
mossy_stone_bricks;tijolos de pedra musgosos;71806A;slw;mossy_stone_brick
cracked_stone_bricks;tijolos de pedra rachados;757575;
chiseled_stone_bricks;tijolos de pedra cinzelados;7A7A7A;
granite;granito;9A6B58;slw
polished_granite;granito polido;A06E5E;sl
diorite;diorito;BDBDBD;slw
polished_diorite;diorito polido;C8C8C8;sl
andesite;andesito;8A8A8A;slw
polished_andesite;andesito polido;8E8E8E;sl
cobbled_deepslate;pedregulho de ardósia;515156;slw
polished_deepslate;ardósia polida;48484C;slw
deepslate_bricks;tijolos de ardósia;474749;slw;deepslate_brick
deepslate_tiles;ladrilhos de ardósia;3A3A3D;slw;deepslate_tile
cracked_deepslate_bricks;tijolos de ardósia rachados;454547;
cracked_deepslate_tiles;ladrilhos de ardósia rachados;38383A;
chiseled_deepslate;ardósia cinzelada;4A4A4E;
reinforced_deepslate;ardósia reforçada;3E4A44;
tuff;tufo;6B6B5F;slw
polished_tuff;tufo polido;7A7A6E;slw
tuff_bricks;tijolos de tufo;6E6E62;slw;tuff_brick
chiseled_tuff;tufo cinzelado;70706A;
chiseled_tuff_bricks;tijolos de tufo cinzelados;72726A;
sandstone;arenito;D8CB9B;slw
cut_sandstone;arenito cortado;DACD9E;l
smooth_sandstone;arenito liso;DBD0A0;sl
chiseled_sandstone;arenito cinzelado;D8CB9B;
red_sandstone;arenito vermelho;B5602A;slw
cut_red_sandstone;arenito vermelho cortado;B8622C;l
smooth_red_sandstone;arenito vermelho liso;B9642E;sl
chiseled_red_sandstone;arenito vermelho cinzelado;B5602A;
bricks;tijolos;96503F;slw;brick
mud_bricks;tijolos de lama;8D6B50;slw;mud_brick
nether_bricks;tijolos do Nether;2D161A;slw;nether_brick
red_nether_bricks;tijolos vermelhos do Nether;4A1A1C;slw;red_nether_brick
cracked_nether_bricks;tijolos do Nether rachados;2A1418;
chiseled_nether_bricks;tijolos do Nether cinzelados;2D161A;
blackstone;pedra negra;2A2429;slw
polished_blackstone;pedra negra polida;353036;slw
polished_blackstone_bricks;tijolos de pedra negra polida;302B32;slw;polished_blackstone_brick
cracked_polished_blackstone_bricks;tijolos de pedra negra polida rachados;2E2930;
chiseled_polished_blackstone;pedra negra polida cinzelada;38333A;
gilded_blackstone;pedra negra dourada;4A3F2E;
end_stone_bricks;tijolos de pedra do End;DBDFA5;slw;end_stone_brick
purpur_block;bloco de púrpura;A77BA7;nsl;purpur
purpur_pillar;pilar de púrpura;A87CA8;
quartz_block;bloco de quartzo;EBE5DE;nsl;quartz
smooth_quartz;quartzo liso;ECE6DF;sl
quartz_bricks;tijolos de quartzo;E8E2DB;
quartz_pillar;pilar de quartzo;EBE6DF;
chiseled_quartz_block;bloco de quartzo cinzelado;EBE5DE;
prismarine;prismarina;63A896;slw
prismarine_bricks;tijolos de prismarina;63AB9B;sl;prismarine_brick
dark_prismarine;prismarina escura;345F4F;sl
bamboo_mosaic;mosaico de bambu;C9B04D;sl
sulfur;enxofre;E5D84A;slw
polished_sulfur;enxofre polido;DFD24A;slw
sulfur_bricks;tijolos de enxofre;D8CB44;slw;sulfur_brick
chiseled_sulfur;enxofre cinzelado;E0D348;
cinnabar;cinábrio;B8322A;slw
polished_cinnabar;cinábrio polido;B0302A;slw
cinnabar_bricks;tijolos de cinábrio;A82C26;slw;cinnabar_brick
chiseled_cinnabar;cinábrio cinzelado;B2302A;
resin_bricks;tijolos de resina;E8742A;slw;resin_brick
chiseled_resin_bricks;tijolos de resina cinzelados;E8742A;
"""

private fun families(): List<Block> = FAMILIES.trimIndent().lines().filter { it.isNotBlank() }.flatMap { ln ->
    val p = ln.split(";")
    val id = p[0]; val base = p[1]; val c = p[2].toInt(16); val fl = p[3]
    val stem = p.getOrNull(4)?.takeIf { it.isNotEmpty() } ?: id
    buildList {
        if ('n' !in fl) add(b(id, cap(base), c))
        if ('s' in fl) add(b("${stem}_stairs", "Escada de $base", c))
        if ('l' in fl) add(b("${stem}_slab", "Laje de $base", c))
        if ('w' in fl) add(b("${stem}_wall", "Muro de $base", c))
    }
}

// ---------------- Demais blocos ----------------
// id;nome;cor
private const val MISC = """
grass_block;Bloco de grama;5F9B3C
dirt;Terra;866043
coarse_dirt;Terra grossa;77553A
rooted_dirt;Terra com raízes;90674A
podzol;Podzol;6B4A2B
mycelium;Micélio;6F6369
dirt_path;Caminho de terra;947A44
farmland;Terra arada;6B4426
mud;Lama;3C3A3F
packed_mud;Lama compactada;8D6B50
clay;Argila;A0A6B4
sand;Areia;DBD3A0
red_sand;Areia vermelha;B5622B
suspicious_sand;Areia suspeita;D5C98F
gravel;Cascalho;837F7E
suspicious_gravel;Cascalho suspeito;7E7978
snow_block;Bloco de neve;F8FEFE
snow;Neve;F0FBFB
powder_snow;Neve em pó;F8FDFD
ice;Gelo;91B8FF
packed_ice;Gelo compactado;7FA5E6
blue_ice;Gelo azul;74A8FD
frosted_ice;Gelo congelado;8DB4F5
moss_block;Bloco de musgo;596D2D
moss_carpet;Tapete de musgo;5B7030
pale_moss_block;Bloco de musgo pálido;A8B2A0
pale_moss_carpet;Tapete de musgo pálido;AAB4A2
pale_hanging_moss;Musgo pálido suspenso;A8B2A0
deepslate;Ardósia;4D4D52
calcite;Calcita;DFE0DC
dripstone_block;Bloco de espeleotema;86695A
pointed_dripstone;Espeleotema pontiagudo;86695A
basalt;Basalto;4B4B50
polished_basalt;Basalto polido;5A5A60
smooth_basalt;Basalto liso;48484D
obsidian;Obsidiana;14111F
crying_obsidian;Obsidiana chorosa;3B0F6B
magma_block;Bloco de magma;8E3E12
netherrack;Netherrack;6F3535
soul_sand;Areia das almas;54402F
soul_soil;Solo das almas;4B3A2D
crimson_nylium;Nylium carmesim;8A2B2F
warped_nylium;Nylium distorcido;2B6C62
nether_wart_block;Bloco de verruga do Nether;7A1C1C
warped_wart_block;Bloco de verruga distorcida;178D82
shroomlight;Luz de cogumelo;F69A4B
nether_brick_fence;Cerca de tijolos do Nether;2D161A
bone_block;Bloco de osso;E3DFC8
ancient_debris;Entulho antigo;5E4136
crimson_roots;Raízes carmesim;8A2B2F
warped_roots;Raízes distorcidas;178D82
crimson_fungus;Fungo carmesim;A33A3A
warped_fungus;Fungo distorcido;178D82
weeping_vines;Vinhas chorosas;8A2B2F
twisting_vines;Vinhas retorcidas;178D82
end_stone;Pedra do End;DDDF9E
end_rod;Bastão do End;F5E9E9
chorus_plant;Planta do coro;8E5D8F
chorus_flower;Flor do coro;A98BAC
dragon_egg;Ovo de dragão;1B0E24
end_portal_frame;Moldura do portal do End;3F6C5A
sponge;Esponja;C9C541
wet_sponge;Esponja molhada;AAB447
sea_lantern;Lanterna do mar;CFE5DC
sea_pickle;Pepino-do-mar;5E8F3A
kelp;Alga;3E7A4B
dried_kelp_block;Bloco de alga seca;2F3A2A
seagrass;Grama-marinha;3D8C4A
lily_pad;Vitória-régia;1F7A2D
azalea;Azaleia;5F7F34
flowering_azalea;Azaleia florida;7C8A3E
azalea_leaves;Folhas de azaleia;50702F
flowering_azalea_leaves;Folhas de azaleia florida;6F7F3A
mangrove_roots;Raízes de mangue;4B3B26
muddy_mangrove_roots;Raízes de mangue lamacentas;47402F
vine;Vinha;3A6B2A
glow_lichen;Líquen luminoso;7FA38A
cactus;Cacto;4E7B33
sugar_cane;Cana-de-açúcar;8FC25E
bamboo;Bambu;7D9B2E
big_dripleaf;Folha pingante grande;5D8B33
small_dripleaf;Folha pingante pequena;5D8B33
hanging_roots;Raízes suspensas;A07A5C
spore_blossom;Flor de esporos;D86BA7
pink_petals;Pétalas rosa;F3A5CE
wildflowers;Flores silvestres;E8C34A
leaf_litter;Folhas caídas;9B5B2B
bush;Arbusto;4B7A2D
red_shrub;Arbusto vermelho;A33A2A
firefly_bush;Arbusto de vaga-lumes;4B7A2D
cactus_flower;Flor de cacto;F28BC2
short_grass;Grama;5F9B3C
tall_grass;Grama alta;5F9B3C
fern;Samambaia;4B7A2D
large_fern;Samambaia grande;4B7A2D
dead_bush;Arbusto seco;7A5A34
short_dry_grass;Grama seca;B8A060
tall_dry_grass;Grama seca alta;B8A060
dandelion;Dente-de-leão;F2D43B
poppy;Papoula;D32F2F
blue_orchid;Orquídea azul;2FB5D4
allium;Alho-silvestre;B27AD1
azure_bluet;Houstônia;E8EEF0
red_tulip;Tulipa vermelha;D32F2F
orange_tulip;Tulipa laranja;F07613
white_tulip;Tulipa branca;E9ECEC
pink_tulip;Tulipa rosa;ED8DAC
oxeye_daisy;Margarida;E8EEF0
cornflower;Centáurea;4A6FD1
lily_of_the_valley;Lírio-do-vale;F0F5F0
wither_rose;Rosa do Wither;1B1B1B
torchflower;Flor-tocha;E87A2A
pitcher_plant;Planta-jarro;4FA7B8
sunflower;Girassol;F2C93B
lilac;Lilás;B58AD0
rose_bush;Roseira;C0302A
peony;Peônia;E8A0C8
closed_eyeblossom;Flor-olho fechada;7A6A7A
open_eyeblossom;Flor-olho aberta;D86A2A
brown_mushroom;Cogumelo marrom;8E6A4A
red_mushroom;Cogumelo vermelho;C0302A
shelf_mushroom;Cogumelo prateleira;C8A070
brown_mushroom_block;Bloco de cogumelo marrom;8E6A4A
red_mushroom_block;Bloco de cogumelo vermelho;C0302A
mushroom_stem;Caule de cogumelo;D8D0C0
hay_block;Fardo de feno;C29B13
straw_bed;Cama de palha;C29B13
pumpkin;Abóbora;C47516
carved_pumpkin;Abóbora entalhada;C47516
jack_o_lantern;Lanterna de abóbora;E0A030
melon;Melancia;8FA82A
honeycomb_block;Bloco de favo de mel;E8A82A
honey_block;Bloco de mel;E8A82A
slime_block;Bloco de slime;7FBF5E
bee_nest;Ninho de abelhas;C9A04A
beehive;Colmeia;B8945F
composter;Composteira;7A5A34
potent_sulfur;Enxofre potente;D6C73A
sulfur_spike;Espinho de enxofre;E5D84A
resin_block;Bloco de resina;E8742A
resin_clump;Aglomerado de resina;E8742A
creaking_heart;Coração do rangedor;5A4A3A
cobweb;Teia de aranha;DADADA
raw_iron_block;Bloco de ferro bruto;C8A18B
raw_copper_block;Bloco de cobre bruto;B06A4E
raw_gold_block;Bloco de ouro bruto;E0B93E
iron_block;Bloco de ferro;D8D8D8
gold_block;Bloco de ouro;FAEC4E
diamond_block;Bloco de diamante;62EDE4
emerald_block;Bloco de esmeralda;2BD05A
lapis_block;Bloco de lápis-lazúli;1F4BA5
redstone_block;Bloco de redstone;AB1B09
coal_block;Bloco de carvão;101010
netherite_block;Bloco de netherita;423E41
amethyst_block;Bloco de ametista;8561BF
budding_amethyst;Ametista brotante;7A55B0
amethyst_cluster;Aglomerado de ametista;9A6FD0
nether_gold_ore;Minério de ouro do Nether;7A4040
nether_quartz_ore;Minério de quartzo do Nether;7A4545
terracotta;Terracota;986A4F
glass;Vidro;C8E6F0
glass_pane;Painel de vidro;C8E6F0
tinted_glass;Vidro escurecido;3A2F40
iron_bars;Barras de ferro;8A8A8A
chain;Corrente;4A4A4A
copper_bars;Barras de cobre;C06C4F
copper_chain;Corrente de cobre;C06C4F
copper_torch;Tocha de cobre;4FA58A
copper_lantern;Lanterna de cobre;C06C4F
copper_chest;Baú de cobre;C06C4F
lightning_rod;Para-raios;C06C4F
torch;Tocha;F2B63B
soul_torch;Tocha da alma;4FB7C9
redstone_torch;Tocha de redstone;C02B1B
lantern;Lanterna;D98B2B
soul_lantern;Lanterna da alma;4FB7C9
campfire;Fogueira;9B5A2A
soul_campfire;Fogueira da alma;4FB7C9
candle;Vela;D8C79A
glowstone;Pedra luminosa;D9A85A
redstone_lamp;Lâmpada de redstone;8A5B2A
ochre_froglight;Luz de rã ocre;F2C96B
verdant_froglight;Luz de rã verdejante;8BD18B
pearlescent_froglight;Luz de rã perolada;E8B6E6
crafting_table;Bancada de trabalho;9A6C3C
furnace;Fornalha;7A7A7A
blast_furnace;Alto-forno;6A6A6E
smoker;Defumador;7A6A5A
chest;Baú;A06F2D
trapped_chest;Baú com armadilha;A06F2D
ender_chest;Baú do End;1B3A3A
barrel;Barril;8A6A3A
shulker_box;Caixa shulker;8E608E
anvil;Bigorna;4A4A4A
chipped_anvil;Bigorna lascada;4A4A4A
damaged_anvil;Bigorna danificada;4A4A4A
grindstone;Pedra de amolar;8A8A8A
stonecutter;Cortador de pedra;7A7A7A
loom;Tear;9A7A4A
cartography_table;Mesa de cartografia;7A5A3A
fletching_table;Mesa de flecharia;B8945F
smithing_table;Mesa de ferraria;3A3A40
lectern;Atril;A07A4A
brewing_stand;Suporte de poções;7A7A7A
cauldron;Caldeirão;3A3A3A
enchanting_table;Mesa de feitiços;7A2A3A
bookshelf;Estante de livros;7B5E3A
chiseled_bookshelf;Estante de livros cinzelada;9A7A4A
jukebox;Jukebox;7A4A2A
note_block;Bloco musical;7A4A2A
bell;Sino;E0B93E
beacon;Sinalizador;62EDE4
conduit;Condutor;8E7A5A
respawn_anchor;Âncora de renascimento;2A1A3A
lodestone;Magnetita;7A7A7E
target;Alvo;E8D9C0
scaffolding;Andaime;C8B070
ladder;Escada de mão;9A7A4A
flower_pot;Vaso de flor;8E4A3A
crafter;Criador;7A7A7A
vault;Cofre;3A3A44
trial_spawner;Gerador de provação;3A4A5A
spawner;Gerador de monstros;1B1B2B
piston;Pistão;9A7A4A
sticky_piston;Pistão pegajoso;7FA05A
observer;Observador;6A6A6A
dispenser;Dispensador;6A6A6A
dropper;Largador;6A6A6A
hopper;Funil;3A3A3A
comparator;Comparador;B8B0A0
repeater;Repetidor;B8B0A0
redstone;Pó de redstone;AB1B09
lever;Alavanca;7A6A5A
tripwire_hook;Gancho de arame;7A6A5A
daylight_detector;Sensor de luz do dia;B8A070
tnt;TNT;D32F2F
rail;Trilho;8A7A6A
powered_rail;Trilho energizado;B8A24A
detector_rail;Trilho detector;8A5A4A
activator_rail;Trilho ativador;8A4A4A
sculk;Sculk;0D1F2A
sculk_vein;Veio de sculk;0D1F2A
sculk_sensor;Sensor sculk;1A4A5A
calibrated_sculk_sensor;Sensor sculk calibrado;1A4A5A
sculk_catalyst;Catalisador sculk;1A3A3A
sculk_shrieker;Gritador sculk;3A5A5A
iron_door;Porta de ferro;D0D0D0
iron_trapdoor;Alçapão de ferro;C0C0C0
stone_button;Botão de pedra;7D7D7D
stone_pressure_plate;Placa de pressão de pedra;7D7D7D
polished_blackstone_button;Botão de pedra negra polida;353036
polished_blackstone_pressure_plate;Placa de pressão de pedra negra polida;353036
heavy_weighted_pressure_plate;Placa de pressão pesada;D8D8D8
light_weighted_pressure_plate;Placa de pressão leve;F9D43C
"""

private fun misc(): List<Block> = MISC.trimIndent().lines().filter { it.isNotBlank() }.map {
    val p = it.split(";")
    b(p[0], p[1], p[2].toInt(16))
}

val BLOCKS: List<Block> =
    (woods() + dyed() + families() + copper() + ores() + corals() + misc()).distinctBy { it.id }

/** 148 -> "2 pilhas + 20 blocos" (pilha = 64, ou 16 / 1 conforme o item). */
fun stacksText(q: Int, stack: Int = 64): String {
    if (q <= 0 || stack <= 1) return ""
    val s = q / stack
    val r = q % stack
    val sp = if (s == 1) "1 pilha" else "$s pilhas"
    val rp = if (r == 1) "1 bloco" else "$r blocos"
    val t = when {
        s == 0 -> rp
        r == 0 -> sp
        else -> "$sp + $rp"
    }
    return if (stack != 64) "$t (pilha de $stack)" else t
}
