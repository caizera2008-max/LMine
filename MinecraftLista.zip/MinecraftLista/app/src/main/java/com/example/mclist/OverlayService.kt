package com.example.mclist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.mclist.STOP"
        private const val CHANNEL = "mclist"
    }

    private lateinit var wm: WindowManager
    private lateinit var store: Store
    private lateinit var panel: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var adapter: BlockAdapter
    private lateinit var footer: TextView
    private lateinit var modeBtn: TextView
    private lateinit var search: EditText

    private val prefListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        if (::adapter.isInitialized) refresh()
    }

    private var showAll = false
    private var query = ""
    private var panelVisible = false
    private var bubbleVisible = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = Store(this)
        startAsForeground()
        buildPanel()
        buildBubble()
        store.register(prefListener)
        wm.addView(panel, panelParams); panelVisible = true
        refresh()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        store.unregister(prefListener)
        runCatching { if (panelVisible) wm.removeView(panel) }
        runCatching { if (bubbleVisible) wm.removeView(bubble) }
        super.onDestroy()
    }

    // ---------- helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = dp(16); y = dp(80)
    }

    private fun roundBg(color: Int, radiusDp: Int, oval: Boolean = false) = GradientDrawable().apply {
        setColor(color)
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radiusDp).toFloat()
    }

    private fun label(text: String, sp: Float = 13f, color: Int = Color.WHITE) = TextView(this).apply {
        this.text = text; textSize = sp; setTextColor(color)
    }

    private fun smallBtn(text: String, bg: Int = 0xFF3A3A3A.toInt(), size: Int = 28) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = roundBg(bg, 6)
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { leftMargin = dp(3) }
    }

    private fun drag(
        p: WindowManager.LayoutParams, target: () -> View, onTap: (() -> Unit)? = null
    ): View.OnTouchListener {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    if (moved) { p.x = sx + dx; p.y = sy + dy; wm.updateViewLayout(target(), p) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) onTap?.invoke(); true }
                else -> false
            }
        }
    }

    private fun setFocusable(on: Boolean) {
        panelParams.flags = if (on)
            panelParams.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else
            panelParams.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (panelVisible) wm.updateViewLayout(panel, panelParams)
    }

    private fun hideKeyboard() {
        search.clearFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        setFocusable(false)
    }

    // ---------- UI ----------

    private fun buildPanel() {
        panelParams = overlayParams(dp(300), dp(440))
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(0xEE1E1E1E.toInt(), 12)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

        // Cabeçalho (arrastável)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(6))
        }
        header.addView(label("⛏ Blocos", 15f).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        modeBtn = smallBtn("Todos", 0xFF2E7D32.toInt(), 28).apply {
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(28)).apply { leftMargin = dp(3) }
            setOnClickListener {
                showAll = !showAll
                text = if (showAll) "Lista" else "Todos"
                refresh()
            }
        }
        header.addView(modeBtn)
        header.addView(smallBtn("—").apply { setOnClickListener { minimize() } })
        header.addView(smallBtn("✕", 0xFF8E2424.toInt()).apply { setOnClickListener { stopSelf() } })
        header.setOnTouchListener(drag(panelParams, { panel }))
        panel.addView(header)

        // Busca
        search = EditText(this).apply {
            hint = "Buscar bloco..."
            setHintTextColor(0xFF999999.toInt())
            setTextColor(Color.WHITE)
            textSize = 13f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_DONE
            background = roundBg(0xFF333333.toInt(), 8)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_DOWN) {
                    setFocusable(true)
                    postDelayed({
                        requestFocus()
                        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                            .showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
                    }, 150)
                }
                false
            }
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_DONE) { hideKeyboard(); true } else false
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { query = s?.toString().orEmpty(); refresh() }
            })
        }
        panel.addView(search, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(4) })

        // Lista
        adapter = BlockAdapter()
        val list = ListView(this).apply {
            this.adapter = this@OverlayService.adapter
            divider = null
        }
        val empty = label("Lista vazia.\nToque em “Todos” e use + para adicionar blocos.", 13f, 0xFFAAAAAA.toInt()).apply {
            gravity = Gravity.CENTER
        }
        list.emptyView = empty
        val frame = FrameLayout(this)
        frame.addView(list, FrameLayout.LayoutParams(-1, -1))
        frame.addView(empty, FrameLayout.LayoutParams(-1, -1))
        panel.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        // Rodapé
        val foot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, 0)
        }
        footer = label("", 12f, 0xFFCCCCCC.toInt()).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        foot.addView(footer)
        foot.addView(label("Desmarcar tudo", 12f, 0xFF81C784.toInt()).apply {
            setPadding(dp(6), dp(4), dp(6), dp(4))
            setOnClickListener { store.uncheckAll(); refresh() }
        })
        panel.addView(foot)
    }

    private fun buildBubble() {
        bubbleParams = overlayParams(dp(56), dp(56))
        bubble = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = roundBg(0xEE2E7D32.toInt(), 0, oval = true)
            setOnTouchListener(drag(bubbleParams, { bubble }) { expand() })
        }
    }

    private fun minimize() {
        hideKeyboard()
        bubbleParams.x = panelParams.x; bubbleParams.y = panelParams.y
        if (panelVisible) { wm.removeView(panel); panelVisible = false }
        if (!bubbleVisible) { wm.addView(bubble, bubbleParams); bubbleVisible = true }
    }

    private fun expand() {
        panelParams.x = bubbleParams.x; panelParams.y = bubbleParams.y
        if (bubbleVisible) { wm.removeView(bubble); bubbleVisible = false }
        if (!panelVisible) { wm.addView(panel, panelParams); panelVisible = true }
    }

    // ---------- dados ----------

    private fun refresh() {
        val q = query.trim()
        adapter.items = BLOCKS.filter {
            (showAll || store.qty(it.id) > 0) &&
                (q.isEmpty() || it.name.contains(q, true) || it.id.contains(q, true))
        }
        adapter.notifyDataSetChanged()
        updateFooter()
    }

    private fun updateFooter() {
        val wanted = BLOCKS.filter { store.qty(it.id) > 0 }
        val done = wanted.count { store.checked(it.id) }
        footer.text = "$done/${wanted.size} ok · segure +/− = 64"
        bubble.text = "$done/${wanted.size}"
    }

    private inner class BlockAdapter : BaseAdapter() {
        var items: List<Block> = emptyList()
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView?.tag as? Row) ?: Row().also { it.root.tag = it }
            row.bind(items[position])
            return row.root
        }
    }

    private inner class Row {
        private lateinit var block: Block
        private val swatch = View(this@OverlayService).apply {
            layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).apply { rightMargin = dp(8) }
        }
        private val name = label("", 13f).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        private val sub = label("", 10f, 0xFF9E9E9E.toInt())
        private val nameBox = LinearLayout(this@OverlayService).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(name); addView(sub)
        }
        private val minus = smallBtn("−")
        private val qty = label("0", 14f).apply {
            gravity = Gravity.CENTER
            minWidth = dp(32)
        }
        private val plus = smallBtn("+")
        private val check = CheckBox(this@OverlayService).apply {
            buttonTintList = ColorStateList.valueOf(0xFF6BD36B.toInt())
        }

        val root = LinearLayout(this@OverlayService).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(3), dp(2), dp(3))
            addView(swatch); addView(nameBox); addView(minus); addView(qty); addView(plus); addView(check)
        }

        init {
            minus.setOnClickListener { change(-1) }
            minus.setOnLongClickListener { change(-64); true }
            plus.setOnClickListener { change(1) }
            plus.setOnLongClickListener { change(64); true }
        }

        private fun change(delta: Int) {
            store.setQty(block.id, store.qty(block.id) + delta)
            refresh()
        }

        private fun strike(on: Boolean) {
            name.paintFlags = if (on) name.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            else name.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            name.alpha = if (on) 0.5f else 1f
        }

        fun bind(b: Block) {
            block = b
            swatch.background = roundBg(b.color, 3)
            name.text = b.name
            val q = store.qty(b.id)
            qty.text = q.toString()
            sub.text = stacksText(q)
            sub.visibility = if (q > 0) View.VISIBLE else View.GONE
            check.setOnCheckedChangeListener(null)
            check.isChecked = store.checked(b.id)
            strike(check.isChecked)
            check.setOnCheckedChangeListener { _, on ->
                store.setChecked(block.id, on)
                strike(on)
                updateFooter()
            }
        }
    }

    // ---------- notificação (serviço em primeiro plano) ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Lista flutuante", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Lista Minecraft ativa")
            .setContentText("Toque em Parar para fechar a lista flutuante")
            .setOngoing(true)
            .addAction(0, "Parar", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else
            startForeground(1, n)
    }
}
