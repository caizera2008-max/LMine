package com.example.mclist

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val pickCode = 10

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Lista Minecraft"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Lista flutuante de blocos sobre o Minecraft.\n\n" +
                "1) Conceda a permissão de sobreposição.\n" +
                "2) (Opcional) Importe uma lista a partir de uma imagem.\n" +
                "3) Toque em Iniciar e abra o Minecraft.\n\n" +
                "Imagem: precisa ter o nome do bloco e o número na mesma linha (ex.: Pedra 148 ou Oak Planks 148). " +
                "O app lê o texto da imagem; ele não reconhece desenhos de blocos."
            setPadding(0, pad / 2, 0, pad)
        })
        status = TextView(this).apply { setPadding(0, 0, 0, pad) }
        root.addView(status)

        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            gravity = Gravity.CENTER
            setOnClickListener { onClick() }
            root.addView(this)
        }

        btn("1. Conceder permissão") { openOverlaySettings() }
        btn("2. Importar lista de uma imagem") { pickImage() }
        btn("3. Iniciar lista flutuante") { start() }
        btn("Parar lista flutuante") { stopService(Intent(this, OverlayService::class.java)) }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this)) "Permissão: concedida ✔" else "Permissão: pendente ✘"
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Conceda a permissão primeiro", Toast.LENGTH_LONG).show()
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        moveTaskToBack(true)
    }

    // ---------- importar imagem ----------

    private fun pickImage() {
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == pickCode && resultCode == RESULT_OK && uri != null) recognize(uri)
    }

    private fun recognize(uri: Uri) {
        Toast.makeText(this, "Lendo imagem...", Toast.LENGTH_SHORT).show()
        val image = try {
            InputImage.fromFilePath(this, uri)
        } catch (e: Exception) {
            Toast.makeText(this, "Não consegui abrir a imagem", Toast.LENGTH_LONG).show()
            return
        }
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(image)
            .addOnSuccessListener { showResult(Importer.parse(it)) }
            .addOnFailureListener {
                Toast.makeText(this, "Falha ao ler a imagem", Toast.LENGTH_LONG).show()
            }
    }

    private fun showResult(r: ImportResult) {
        val dlg = AlertDialog.Builder(this)
        if (r.found.isEmpty()) {
            dlg.setTitle("Nada reconhecido")
                .setMessage("Não achei blocos com quantidade. Use uma imagem nítida com o nome e o número na mesma linha, ex.: Pedra 148.")
                .setPositiveButton("OK", null).show()
            return
        }
        val msg = buildString {
            r.found.forEach { append("• ${it.block.name}: ${it.qty} (${stacksText(it.qty)})\n") }
            if (r.unknown.isNotEmpty()) {
                append("\nNão reconhecidos:\n")
                r.unknown.take(10).forEach { append("• $it\n") }
                if (r.unknown.size > 10) append("… e mais ${r.unknown.size - 10}\n")
            }
        }
        val map = r.found.associate { it.block.id to it.qty }
        val store = Store(this)
        dlg.setTitle("Lista reconhecida")
            .setMessage(msg)
            .setPositiveButton("Somar") { _, _ ->
                store.addMany(map, false); done()
            }
            .setNeutralButton("Substituir tudo") { _, _ ->
                store.addMany(map, true); done()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun done() =
        Toast.makeText(this, "Lista atualizada!", Toast.LENGTH_LONG).show()
}
