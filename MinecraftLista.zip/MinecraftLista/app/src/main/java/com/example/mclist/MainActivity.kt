package com.example.mclist

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val pickCode = 10
    private var fromOverlay = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Lista Minecraft"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Lista flutuante de blocos sobre o Minecraft.\n\n" +
                "1) Conceda a permissão de sobreposição.\n" +
                "2) (Opcional) Importe uma lista a partir de uma imagem.\n" +
                "3) Toque em Iniciar e abra o Minecraft.\n\n" +
                "Imagem: o app lê o texto (nome do bloco e número). Funciona com \"Pedra 148\", " +
                "\"148x Pedra\", \"Oak Planks 148\" e \"2x64 + 20\". Também dá para importar pelo botão 📷 da lista flutuante."
            setPadding(0, pad / 2, 0, pad)
        })
        status = TextView(this).apply { setPadding(0, 0, 0, pad) }
        root.addView(status)

        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            gravity = Gravity.CENTER
            setOnClickListener { onClick() }
            root.addView(this)
        }

        btn("1. Conceder permissão") { openOverlaySettings() }
        btn("2. Importar lista de uma imagem") { pickImage() }
        btn("3. Iniciar lista flutuante") { start() }
        btn("Parar lista flutuante") { stopService(Intent(this, OverlayService::class.java)) }

        setContentView(ScrollView(this).apply { addView(root) })
        handlePick(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handlePick(intent)
    }

    private fun handlePick(i: Intent?) {
        if (i?.getBooleanExtra("pick", false) == true) {
            i.removeExtra("pick")
            fromOverlay = true
            pickImage()
        }
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this)) "Permissão: concedida ✔" else "Permissão: pendente ✘"
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Conceda a permissão primeiro", Toast.LENGTH_LONG).show()
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        moveTaskToBack(true)
    }

    // ---------- importar imagem ----------

    private fun pickImage() {
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode) return
        val uri = data?.data
        if (resultCode == RESULT_OK && uri != null) recognize(uri) else finishFlow()
    }

    private fun finishFlow() {
        if (fromOverlay) { fromOverlay = false; moveTaskToBack(true) }
    }

    private fun loadBitmap(uri: Uri): Bitmap? = try {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > 2400) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
        if (bmp != null) {
            val deg = contentResolver.openInputStream(uri)?.use { s ->
                when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90; 3 -> 180; 8 -> 270; else -> 0
                }
            } ?: 0
            if (deg != 0) {
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height,
                    Matrix().apply { postRotate(deg.toFloat()) }, true)
            }
            // Imagens pequenas: amplia para o OCR enxergar melhor (fontes pixeladas do Minecraft).
            if (maxOf(bmp.width, bmp.height) < 1200) {
                bmp = Bitmap.createScaledBitmap(bmp, bmp.width * 2, bmp.height * 2, true)
            }
        }
        bmp
    } catch (e: Exception) {
        null
    }

    private fun filtered(src: Bitmap, m: ColorMatrix): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val p = Paint().apply { colorFilter = ColorMatrixColorFilter(m) }
        Canvas(out).drawBitmap(src, 0f, 0f, p)
        return out
    }

    private fun recognize(uri: Uri) {
        Toast.makeText(this, "Lendo imagem...", Toast.LENGTH_SHORT).show()
        val bmp = loadBitmap(uri)
        if (bmp == null) {
            Toast.makeText(this, "Não consegui abrir a imagem", Toast.LENGTH_LONG).show()
            finishFlow()
            return
        }
        // Três leituras: normal, cinza com contraste, e invertida (texto claro em fundo escuro).
        val gray = ColorMatrix().apply {
            setSaturation(0f)
            postConcat(ColorMatrix(floatArrayOf(
                1.6f, 0f, 0f, 0f, -60f,
                0f, 1.6f, 0f, 0f, -60f,
                0f, 0f, 1.6f, 0f, -60f,
                0f, 0f, 0f, 1f, 0f)))
        }
        val inverted = ColorMatrix(gray).apply {
            postConcat(ColorMatrix(floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f)))
        }
        val variants = listOf(bmp, filtered(bmp, gray), filtered(bmp, inverted))
        val results = mutableListOf<ImportResult>()
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        fun next(i: Int) {
            if (i >= variants.size) {
                rec.close()
                showResult(Importer.merge(results))
                return
            }
            rec.process(InputImage.fromBitmap(variants[i], 0))
                .addOnSuccessListener { results += Importer.parse(it); next(i + 1) }
                .addOnFailureListener { next(i + 1) }
        }
        next(0)
    }

    private fun showResult(r: ImportResult) {
        val dlg = AlertDialog.Builder(this)
        if (r.found.isEmpty()) {
            val raw = r.raw.trim().replace("\n", " | ").take(600)
            dlg.setTitle("Nada reconhecido")
                .setMessage(
                    "Não achei blocos com quantidade.\n\nTexto que o app leu:\n" +
                        (if (raw.isEmpty()) "(nada — a imagem pode estar muito pequena ou borrada)" else raw) +
                        "\n\nSe o texto lido estiver certo mas os nomes não batem, me mande esse texto que eu ajusto."
                )
                .setPositiveButton("OK") { _, _ -> finishFlow() }
                .show()
            return
        }
        val msg = buildString {
            r.found.forEach { append("• ${it.block.name}: ${it.qty} (${stacksText(it.qty, it.block.stack)})\n") }
            if (r.unknown.isNotEmpty()) {
                append("\nNão reconhecidos:\n")
                r.unknown.take(10).forEach { append("• $it\n") }
                if (r.unknown.size > 10) append("… e mais ${r.unknown.size - 10}\n")
            }
        }
        val map = r.found.associate { it.block.id to it.qty }
        val store = Store(this)
        dlg.setTitle("Lista reconhecida")
            .setMessage(msg)
            .setPositiveButton("Somar") { _, _ -> store.addMany(map, false); done() }
            .setNeutralButton("Substituir tudo") { _, _ -> store.addMany(map, true); done() }
            .setNegativeButton("Cancelar") { _, _ -> finishFlow() }
            .setOnCancelListener { finishFlow() }
            .show()
    }

    private fun done() {
        Toast.makeText(this, "Lista atualizada!", Toast.LENGTH_LONG).show()
        finishFlow()
    }
}
