package com.example.mclist

import android.content.Context

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("mclist", Context.MODE_PRIVATE)

    fun qty(id: String) = p.getInt("q_$id", 0)
    fun setQty(id: String, v: Int) = p.edit().putInt("q_$id", v.coerceAtLeast(0)).apply()

    fun checked(id: String) = p.getBoolean("c_$id", false)
    fun setChecked(id: String, v: Boolean) = p.edit().putBoolean("c_$id", v).apply()

    fun uncheckAll() {
        val e = p.edit()
        p.all.keys.filter { it.startsWith("c_") }.forEach { e.remove(it) }
        e.apply()
    }

    fun addMany(m: Map<String, Int>, replace: Boolean) {
        val e = p.edit()
        if (replace) p.all.keys.filter { it.startsWith("q_") || it.startsWith("c_") }.forEach { e.remove(it) }
        m.forEach { (id, v) ->
            val cur = if (replace) 0 else qty(id)
            e.putInt("q_$id", (cur + v).coerceAtLeast(0))
        }
        e.apply()
    }

    fun register(l: android.content.SharedPreferences.OnSharedPreferenceChangeListener) =
        p.registerOnSharedPreferenceChangeListener(l)

    fun unregister(l: android.content.SharedPreferences.OnSharedPreferenceChangeListener) =
        p.unregisterOnSharedPreferenceChangeListener(l)
}
