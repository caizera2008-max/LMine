package com.example.mclist

import com.google.mlkit.vision.text.Text
import java.text.Normalizer
import kotlin.math.abs

data class Found(val block: Block, val qty: Int)
data class ImportResult(val found: List<Found>, val unknown: List<String>)

/** Converte o texto lido (OCR) de uma imagem em blocos + quantidades. */
object Importer {

    private class Piece(val text: String, val left: Int, val cy: Float, val h: Int)

    private fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase()
            .filter { it.isLetter() }

    // Nomes aceitos: português, id em inglês ("oak planks") e "block of iron".
    private val keys: List<Pair<String, Block>> by lazy {
        val l = mutableListOf<Pair<String, Block>>()
        for (b in BLOCKS) {
            l += norm(b.name) to b
            l += norm(b.id.replace('_', ' ')) to b
            if (b.id.endsWith("_block"))
                l += ("blockof" + norm(b.id.removeSuffix("_block").replace('_', ' '))) to b
        }
        l
    }

    fun parse(text: Text): ImportResult {
        val pieces = text.textBlocks.flatMap { it.lines }.mapNotNull { ln ->
            ln.boundingBox?.let { Piece(ln.text, it.left, it.exactCenterY(), it.height()) }
        }.sortedBy { it.cy }

        // Junta pedaços que estão na mesma altura (colunas de tabela) em uma linha só.
        val rows = mutableListOf<MutableList<Piece>>()
        for (p in pieces) {
            val last = rows.lastOrNull()
            if (last != null && abs(p.cy - last.map { it.cy }.average()) < p.h * 0.6) last.add(p)
            else rows.add(mutableListOf(p))
        }

        val totals = linkedMapOf<Block, Int>()
        val unknown = mutableListOf<String>()
        for (row in rows) {
            val line = row.sortedBy { it.left }.joinToString(" ") { it.text }
            val num = Regex("\\d+").find(line) ?: continue
            val qty = num.value.toIntOrNull() ?: continue
            if (qty <= 0) continue
            val namePart = norm(line.replace(Regex("[x×]?\\s*\\d+\\s*[x×]?"), " "))
            val block = match(namePart)
            if (block != null) totals[block] = (totals[block] ?: 0) + qty
            else if (namePart.length >= 3) unknown.add(line.trim())
        }
        return ImportResult(totals.map { Found(it.key, it.value) }, unknown)
    }

    private fun match(t: String): Block? {
        if (t.length < 3) return null
        keys.firstOrNull { it.first == t }?.let { return it.second }

        var best: Block? = null
        var bestD = Int.MAX_VALUE
        for ((k, b) in keys) {
            if (abs(k.length - t.length) > 3) continue
            val d = lev(k, t)
            if (d <= maxOf(1, k.length / 5) && d < bestD) { best = b; bestD = d }
        }
        if (best != null) return best

        return keys.filter { t.contains(it.first) && it.first.length >= t.length * 0.7 }
            .maxByOrNull { it.first.length }?.second
    }

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }
}
