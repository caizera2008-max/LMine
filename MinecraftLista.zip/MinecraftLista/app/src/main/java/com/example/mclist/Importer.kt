package com.example.mclist

import com.google.mlkit.vision.text.Text
import java.text.Normalizer
import kotlin.math.abs

data class Found(val block: Block, val qty: Int)
data class ImportResult(val found: List<Found>, val unknown: List<String>, val raw: String = "")

/** Converte o texto lido (OCR) de uma imagem em blocos + quantidades. */
object Importer {

    private class Piece(val text: String, val left: Int, val top: Int, val bottom: Int) {
        val cy get() = (top + bottom) / 2f
        val h get() = (bottom - top).coerceAtLeast(1)
    }

    private class Row(first: Piece) {
        val pieces = mutableListOf(first)
        var top = first.top
        var bottom = first.bottom
    }

    private class Qty(val value: Int, val rest: String)

    private fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase()
            .filter { it.isLetter() }

    // Nomes aceitos: português, id em inglês ("oak planks") e "block of iron".
    private val keyList: List<Pair<String, Block>> by lazy {
        val l = mutableListOf<Pair<String, Block>>()
        for (b in BLOCKS) {
            l += norm(b.name) to b
            l += norm(b.id.replace('_', ' ')) to b
            if (b.id.endsWith("_block"))
                l += ("blockof" + norm(b.id.removeSuffix("_block").replace('_', ' '))) to b
        }
        l
    }
    private val exact: Map<String, Block> by lazy {
        val m = HashMap<String, Block>()
        for ((k, b) in keyList) if (k.isNotEmpty() && !m.containsKey(k)) m[k] = b
        m
    }

    fun parse(text: Text): ImportResult {
        val pieces = text.textBlocks.flatMap { it.lines }.mapNotNull { ln ->
            ln.boundingBox?.let { Piece(ln.text, it.left, it.top, it.bottom) }
        }.sortedBy { it.cy }

        // Junta pedaços que estão na mesma altura (colunas de tabela) em uma linha só.
        val rows = mutableListOf<Row>()
        for (p in pieces) {
            val r = rows.lastOrNull()
            if (r != null) {
                val rh = (r.bottom - r.top).coerceAtLeast(1)
                val rcy = (r.top + r.bottom) / 2f
                if (abs(p.cy - rcy) < 0.7f * maxOf(rh, p.h)) {
                    r.pieces += p
                    r.top = minOf(r.top, p.top)
                    r.bottom = maxOf(r.bottom, p.bottom)
                    continue
                }
            }
            rows += Row(p)
        }
        val lines = rows.map { r -> r.pieces.sortedBy { it.left }.joinToString(" ") { it.text } }

        val totals = linkedMapOf<Block, Int>()
        val unknown = mutableListOf<String>()

        fun handle(name: String, qty: Int, original: String) {
            if (qty <= 0 || qty > 1_000_000) return
            val block = match(name)
            if (block != null) totals[block] = (totals[block] ?: 0) + qty
            else if (name.length >= 3) unknown.add(original.trim())
        }

        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            val q = extract(line)
            if (q != null) {
                val name = norm(cleanName(q.rest))
                if (name.length < 3 && i + 1 < lines.size && extract(lines[i + 1]) == null) {
                    // número numa linha e nome na seguinte
                    handle(norm(lines[i + 1]), q.value, lines[i + 1]); i += 2; continue
                }
                handle(name, q.value, line); i++; continue
            }
            val name = norm(line)
            if (name.length >= 3 && i + 1 < lines.size) {
                val nq = extract(lines[i + 1])
                if (nq != null && norm(cleanName(nq.rest)).isEmpty()) {
                    // nome numa linha e número na seguinte
                    handle(name, nq.value, line); i += 2; continue
                }
            }
            i++
        }
        return ImportResult(totals.map { Found(it.key, it.value) }, unknown, text.text)
    }

    /** Junta o resultado de várias leituras (imagem normal, contraste, invertida). */
    fun merge(list: List<ImportResult>): ImportResult {
        if (list.isEmpty()) return ImportResult(emptyList(), emptyList(), "")
        val best = list.sortedWith(compareBy({ -it.found.size }, { it.unknown.size })).first()
        val have = best.found.map { it.block }.toMutableSet()
        val all = best.found.toMutableList()
        for (r in list) for (f in r.found) if (have.add(f.block)) all.add(f)
        return ImportResult(all, best.unknown, best.raw)
    }

    private fun cleanName(s: String) = s.replace(Regex("[x×]?\\s*\\d+\\s*[x×]?"), " ")

    /** Acha a quantidade na linha: "148", "148x", "x148", "2x64 + 20", "2 pilhas + 20". */
    private fun extract(line0: String): Qty? {
        val line = line0.replace(Regex("(?<=\\d)[.,](?=\\d{3}(?!\\d))"), "")
        val ic = RegexOption.IGNORE_CASE

        Regex("(\\d+)\\s*[x×]\\s*64(?:\\s*\\+\\s*(\\d+))?", ic).find(line)?.let { m ->
            val a = m.groupValues[1].toIntOrNull() ?: return@let
            val r = m.groupValues[2].toIntOrNull() ?: 0
            return Qty(a * 64 + r, line.replaceRange(m.range, " "))
        }
        Regex("(\\d+)\\s*(?:pilhas?|stacks?|packs?)(?:\\s*(?:\\+|e|and)?\\s*(\\d+))?", ic).find(line)?.let { m ->
            val a = m.groupValues[1].toIntOrNull() ?: return@let
            val r = m.groupValues[2].toIntOrNull() ?: 0
            return Qty(a * 64 + r, line.replaceRange(m.range, " "))
        }
        val m = Regex("\\d+").find(line) ?: return null
        val v = m.value.toIntOrNull() ?: return null
        return Qty(v, line.replaceRange(m.range, " "))
    }

    private fun match(t: String): Block? {
        if (t.length < 3) return null
        exact[t]?.let { return it }

        var best: Block? = null
        var bestD = Int.MAX_VALUE
        for ((k, b) in keyList) {
            if (abs(k.length - t.length) > 4) continue
            val limit = maxOf(1, (maxOf(k.length, t.length) * 0.22).toInt())
            val d = lev(k, t)
            if (d <= limit && d < bestD) { best = b; bestD = d }
        }
        if (best != null) return best

        return keyList.filter { t.contains(it.first) && it.first.length >= t.length * 0.7 }
            .maxByOrNull { it.first.length }?.second
    }

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }
}
