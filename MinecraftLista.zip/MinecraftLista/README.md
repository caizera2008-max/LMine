# Lista Minecraft (overlay)

App Android (Kotlin) com lista flutuante de blocos do Minecraft: quantidades, marcar/desmarcar e busca,
aparecendo sobre o jogo.

## Gerar o APK
1. Instale o Android Studio (versão recente) e abra esta pasta (File > Open).
2. Aguarde o "Gradle Sync" terminar (precisa de internet na primeira vez).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O arquivo fica em app/build/outputs/apk/debug/app-debug.apk. Copie para o celular e instale
   (permita "instalar apps desconhecidos").

## Usar
1. Abra o app, toque em "Conceder permissão" e ative "Permitir exibir sobre outros apps".
2. Toque em "Iniciar lista flutuante" e abra o Minecraft.
3. Aba "Todos": use + / − para definir a quantidade (segure = ±64). Aba "Lista": só o que você precisa.
4. Marque a caixinha quando já tiver o bloco. "—" minimiza para uma bolinha; toque nela para reabrir.
5. Arraste pelo cabeçalho para mover. "✕" ou o botão Parar na notificação fecham tudo.
6. Toque na busca para digitar; confirme no "OK" do teclado para devolver o toque ao jogo.

## Importar de imagem
No app, "Importar lista de uma imagem": escolha um print com linhas como "Pedra 148" ou "Oak Planks 148".
O app lê o texto (OCR do Google ML Kit, no próprio celular), confere os nomes (PT/EN) e mostra o que achou
para você escolher "Somar" ou "Substituir tudo". Não reconhece desenhos/texturas de blocos, só texto.

## Pilhas
Cada bloco mostra a conta de pilhas (64): 148 -> "2 pilhas + 20 blocos".

## Atualização
- Catálogo grande: madeiras (tábuas, escadas, lajes, cercas, portas...), pedras com escada/laje/muro, 16 cores
  (lã, tapete, concreto, vidro, cama, vela...), cobre (4 estágios + encerado), minérios, corais, redstone, plantas,
  blocos do 26.2 (enxofre/cinábrio) e do 26.3 (choupo, almofadas, escadas de lã/concreto).
- Importação mais robusta: 3 leituras da imagem (normal, contraste, invertida), aceita "2x64 + 20" e "2 pilhas + 20",
  nome e número em linhas separadas, e mostra o texto lido quando nada é reconhecido.
- Botão 📷 na lista flutuante abre o seletor de imagem direto.
